DROP TABLE IF EXISTS `#__modelo`
