CREATE TABLE IF NOT EXISTS `#__modelo`
(
	`id` int primary key auto_increment NOT NULL,
	`categoria` VARCHAR(45) NOT NULL, 
	`imagem` varchar(100) NOT NULL, 
	`descricao` VARCHAR(105) NOT NULL
);
