# Simple Backup to CMS Joomla 2.5 and 3.x

### Com a compra do GitHub pela (MS) fiz uma cópia deste repositório no GitLab.
https://gitlab.com/ribafs/com_simplebackup


[![Licença](https://img.shields.io/aur/license/yaourt.svg)](https://github.com/ribafs/simplebackup/blob/master/LICENSE)

## Main Resources
    Backup to download on desktop    
    Very simple backup
    Support Joomla 2.5 and Joomla 3.x
    Translated to portuguese and english


## Documentação Em português
http://ribafs.org/portal/joomla-3/extensoes/99-minhas-extensoes

Configurado para suportar sites com até 5GB compactados. Caso seu site compactado resulte em mais de 5GB você pode ajustar o ini_set no simplebackup.php para um valor que suporte seu site.

## Instalação
https://github.com/ribafs/com_simplebackup

## Aviso
Agora é gerado apenas um arquivo zip para download.
O script sql do banco vem no raiz do site.

License
-------

The GPL 3.0 License (GPL 3)
