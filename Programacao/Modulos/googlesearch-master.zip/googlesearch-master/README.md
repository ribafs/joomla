# Módulo de busca para sites usando a busca do Google

## Para Joomla 2.5 e 3.x

Efetua busca no site usando o motor do Google.


# Licença

GPL 3
