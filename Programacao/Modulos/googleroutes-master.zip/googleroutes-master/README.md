# Módulo que usa as rotas do Google para dois endereços
## Para Joomla 2.5 e 3.x

Indique um endereço e depois o segundo para receber a rota entre ambos e o mapa partindo da origem ao destino.

# Licença

GPL 3
