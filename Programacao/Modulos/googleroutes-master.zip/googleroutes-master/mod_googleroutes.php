<?php
/**
* @module Percurso
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author - Ribamar FS - 11/2018
*/

defined('_JEXEC') or die('Restricted access');

?>
<a href="https://www.google.com/maps/dir///@-3.7294526,-38.5422647,15z" target="_blank">Abrir o Mapa</a>
