# percurso-google
Módulo para Joomla 2.5 e 3 que mostra um mapa do Google e permite que se entre origem e destino e ele traça o percurso entre a origem e o destino.

## Demo
http://ribafs.org
