# Pequeno pacote/package para Joomla 3 

Apenas para demonstrar coo se cria um package para Joomla 3

Este pequeno pacote empacota o componente com_modelo e o módulo mod_modelo em apenas uma extensão. Mas o pacote no Joomla pode conter inúmeras extensões.


## Licença

GPL 3
