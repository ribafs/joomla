jQuery(function($) {

	// YOUR SCRIPT HERE

});
