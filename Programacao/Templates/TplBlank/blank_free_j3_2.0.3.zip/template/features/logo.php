<?php

/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
 */

defined('_JEXEC') or die();

class HelixUltimateFeatureLogo
{

  private $params;

  public function __construct($params)
  {
    $this->params = $params;
    $this->position = 'logo';
  }

  public function renderFeature()
  {
    $header_style = $this->params->get('header_style');
    $template_name = JFactory::getApplication()->getTemplate();
    $menu_type = $this->params->get('menu_type');
    $offcanvs_position = $this->params->get('offcanvas_position', 'right');
    $doc = \JFactory::getDocument();
    $logo_width = $this->params->get('logo_width');
    $logo_width_init = $logo_width ? ' width="'.$logo_width.'"' : '';
    $logo_height = $this->params->get('logo_height');
    $logo_height_init = $logo_height ? ' height="'.$logo_height.'"' : '';

    if (in_array($header_style, ['style-3'])) {
      $nav_item = '';
    } else {
      $nav_item = 'uk-navbar-item ';
    }
    $presetVars = (array) json_decode($this->params->get('preset'));
    $preset = (isset($presetVars['preset']) && $presetVars['preset']) ? $presetVars['preset'] : 'default';

    if ($this->params->get('logo_type') == 'image') {
      if ($this->params->get('logo_image')) {
        $path = \JPATH_ROOT . '/' . $this->params->get('logo_image');
      } else {
        $path = \JPATH_ROOT . '/templates/' . $template_name . '/images/presets/' . $preset . '/logo.png';
      }
    }

    $html = '';

    if ($offcanvs_position == 'left') {
      if ($menu_type == 'mega') {
        $html .= '<a aria-label="' . JText::_('HELIX_ULTIMATE_NAVIGATION') . '" class="uk-hidden@m uk-navbar-item" uk-toggle="target: #offcanvas-overlay"><span class="uk-navbar-toggle-icon" aria-hidden="true" title="' . JText::_('HELIX_ULTIMATE_NAVIGATION') . '" uk-navbar-toggle-icon></span></a>';
      } else {
        $html .= '<a aria-label="' . JText::_('HELIX_ULTIMATE_NAVIGATION') . '" class="offcanvas-toggler-right uk-navbar-item" uk-toggle="target: #offcanvas-overlay"><span class="uk-navbar-toggle-icon" aria-hidden="true" title="' . JText::_('HELIX_ULTIMATE_NAVIGATION') . '" uk-navbar-toggle-icon></span></a>';
      }
    }

    $custom_logo_class = '';
    $sitename = \JFactory::getApplication()->get('sitename');

    if ($this->params->get('mobile_logo')) {
      $custom_logo_class = ' d-none d-lg-inline-block';
    }

    if ($this->params->get('logo_type') == 'image') {
      if ($this->params->get('logo_image')) {

        $html .= '<a class="'.$nav_item.'uk-logo" href="' . \JURI::base(true) . '/">';

        $html .= '<img'.$logo_width_init.$logo_height_init.' class="logo-image' . $custom_logo_class . '" src="' . $this->params->get('logo_image') . '" alt="' . $sitename . '">';

        if ($this->params->get('mobile_logo')) {
          $html .= '<img class="logo-image-phone d-inline-block d-lg-none" src="' . $this->params->get('mobile_logo') . '" alt="' . $sitename . '">';
        }

        $html .= '</a>';
      } else {

        $html .= '<a class="'.$nav_item.'uk-logo" href="' . \JURI::base(true) . '/">';

        $html .= '<img'.$logo_width_init.$logo_height_init.' class="logo-image' . $custom_logo_class . '" src="' . JURI::base(true) . '/templates/' . $template_name . '/images/presets/' . $preset . '/logo.png" alt="' . $sitename . '">';

        if ($this->params->get('mobile_logo')) {
          $html .= '<img class="logo-image-phone d-inline-block d-lg-none" src="' . $this->params->get('mobile_logo') . '" alt="' . $sitename . '">';
        }

        $html .= '</a>';
      }
    } else {
      if ($this->params->get('logo_text')) {
        $html .= '<a class="'.$nav_item.'uk-logo" href="' . \JURI::base(true) . '/">' . $this->params->get('logo_text') . '</a>';
      } else {
        $html .= '<a class="'.$nav_item.'uk-logo" href="' . \JURI::base(true) . '/">' . $sitename . '</a>';
      }

      if ($this->params->get('logo_slogan')) {
        $html .= '<span class="logo-slogan">' . $this->params->get('logo_slogan') . '</span>';
      }
    }
    if ($this->params->get('enabled_logo_tooltip'))
    {
      $html .= '<div class="uk-child-width-1-1" uk-drop="boundary: .uk-logo">';
      $html .= '<div class="uk-card uk-card-body uk-card-default uk-card-small">';
      $html .= '<div>'.$this->params->get('logo_tooltip').'</div>';
      $html .= '</div>';
      $html .= '  </div>';
    }
    return $html;
  }
}
