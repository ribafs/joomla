<?php

/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
 */

defined('_JEXEC') or die();

class HelixUltimateFeatureCookie
{
    private $params;

    public function __construct($params)
    {
        $this->params = $params;
        $this->position = 'cookie_banner';
        $this->app      = JFactory::getApplication();
        $this->input    = $this->app->input;
    }

    public function renderFeature()
    {
        $cookie = $this->app->input->cookie;
        $cookie_position = $this->params->get('cookie_position', 'bottom-left');
        $cookie_style = $this->params->get('cookie_style', '');
        $cookie_style_cls = $cookie_style ? ' uk-notification-message-' . $cookie_style : '';
        $cookie_button = $this->params->get('cookie_button', '');

        if ($cookie->get('cookieAllowed') != 'true' && $this->params->get('enabled_cookie_banner')) {

            $output = '';

            if ($this->params->get('cookie_content')) {
                $output .= '<div class="uk-notification uk-notification-' . $cookie_position . '">';
                $output .= '<div class="uk-notification-message' . $cookie_style_cls . ' uk-panel">';

                $output .= '<div>' . $this->params->get('cookie_content')  . '</div>';

                if (empty($cookie_button)) {
                    $output .= '<button type="button" class="js-accept uk-notification-close uk-close uk-icon" data-uk-close="" data-uk-toggle="target: !.uk-notification; animation: uk-animation-fade"></button>';
                } else {
                    $output .= ' <p class="uk-margin"><button type="button" class="js-accept uk-button uk-button-' . $cookie_button . ' uk-width-1-1" data-uk-toggle="target: !.uk-notification; animation: uk-animation-fade">' . $this->params->get('cookie_button_text') . '</button></p>';
                }

                $output .= '</div>';
                $output .= '</div>';
            }
            return $output;
        }
    }
}
