<?php
/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
*/

defined ('_JEXEC') or die();

class HelixUltimateFeatureSocial
{

	private $params;

	public function __construct( $params )
	{
		$this->params = $params;
		$this->position = $this->params->get('social_pos');
	}

	public function renderFeature()
	{
		$link = $this->params->get('social_icons_link') ? ' target="_blank"' : '';
		$link_button = $this->params->get('social_icons_button') ? ' uk-icon-button' : '';
		$facebook = $this->params->get('facebook');
		$twitter = $this->params->get('twitter');
		$pinterest = $this->params->get('pinterest');
		$youtube = $this->params->get('youtube');
		$linkedin = $this->params->get('linkedin');
		$dribbble = $this->params->get('dribbble');
		$instagram = $this->params->get('instagram');
		$behance = $this->params->get('behance');
		$whatsapp = $this->params->get('whatsapp');
		$flickr = $this->params->get('flickr');
		$custom = $this->params->get('custom');

		if( $this->params->get('social_pos') && ( $facebook || $twitter || $pinterest || $youtube || $linkedin || $dribbble || $instagram || $behance || $flickr || $custom ) )
		{
			$html  = '<ul class="uk-grid-small uk-flex-inline uk-flex-middle uk-flex-nowrap" uk-grid>';

			if( $facebook )
			{
				$html .= '<li class="social-icon-facebook"><a class="tm-social'.$link_button.'"'.$link.' href="'. $facebook .'" aria-label="facebook"><span class="fab fa-facebook-f" aria-hidden="true"></span></a></li>';
			}

			if( $twitter )
			{
				$html .= '<li class="social-icon-twitter"><a class="tm-social'.$link_button.'"'.$link.' href="'. $twitter .'" aria-label="twitter"><span class="fab fa-twitter" aria-hidden="true"></span></a></li>';
			}

			if( $pinterest )
			{
				$html .= '<li class="social-icon-pinterest"><a class="tm-social'.$link_button.'"'.$link.' href="'. $pinterest .'" aria-label="Pinterest"><span class="fab fa-pinterest" aria-hidden="true"></span></a></li>';
			}

			if( $youtube )
			{
				$html .= '<li><a class="tm-social'.$link_button.'"'.$link.' href="'. $youtube .'" aria-label="Youtube"><span class="fab fa-youtube" aria-hidden="true"></span></a></li>';
			}

			if( $linkedin )
			{
				$html .= '<li class="social-icon-linkedin"><a class="tm-social'.$link_button.'"'.$link.' href="'. $linkedin .'" aria-label="LinkedIn"><span class="fab fa-linkedin-in" aria-hidden="true"></span></a></li>';
			}

			if( $dribbble )
			{
				$html .= '<li class="social-icon-dribbble"><a class="tm-social'.$link_button.'"'.$link.' href="'. $dribbble .'" aria-label="Dribbble"><span class="fab fa-dribbble" aria-hidden="true"></span></a></li>';
			}

			if( $instagram )
			{
				$html .= '<li class="social-icon-instagram"><a class="tm-social'.$link_button.'"'.$link.' href="'. $instagram .'" aria-label="Instagram"><span class="fab fa-instagram" aria-hidden="true"></span></a></li>';
			}

			if( $behance )
			{
				$html .= '<li class="social-icon-behance"><a class="tm-social'.$link_button.'"'.$link.' href="'. $behance .'" aria-label="Behance"><span class="fab fa-behance" aria-hidden="true"></span></a></li>';
			}

			if( $flickr )
			{
				$html .= '<li class="social-icon-flickr"><a class="tm-social'.$link_button.'"'.$link.' href="'. $flickr .'" aria-label="Flickr"><span class="fab fa-flickr" aria-hidden="true"></span></a></li>';
			}

			if( $whatsapp )
			{
				$html .= '<li class="social-icon-whatsapp"><a class="tm-social'.$link_button.'"'.$link.' href="whatsapp://send?abid='. $whatsapp .'&text=Hi" aria-label="WhatsApp"><span class="fab fa-whatsapp" aria-hidden="true"></span></a></li>';
			}

			if( $custom ) {
				$explt_custom = explode(' ', $custom);
				$html .= '<li class="social-icon-custom"><a class="tm-social'.$link_button.'"'.$link.' href="'. $explt_custom[1] .'"><span class="fab '. $explt_custom[0] .'" aria-hidden="true"></span></a></li>';
			}

			$html .= '</ul>';

			return $html;
		}

	}
}
