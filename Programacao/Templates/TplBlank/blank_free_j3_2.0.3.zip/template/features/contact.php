<?php
/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
*/

defined ('_JEXEC') or die();

class HelixUltimateFeatureContact
{
	private $params;

	public function __construct($params)
	{
		$this->params = $params;
		$this->position = $this->params->get('contact_pos', '');
	}

	public function renderFeature()
	{
		$conditions = $this->params->get('contact_pos') && ($this->params->get('contact_location') || $this->params->get('contact_phone') || $this->params->get('contact_email') || $this->params->get('contact_time') || $this->params->get('contact_custom'));

		if($conditions)
		{
			$output = '<div class="tm-contact-info uk-grid-small uk-flex-middle" uk-grid>';

			if($this->params->get('contact_location'))
			{
				$output .= '<div class="sp-contact-location"><span class="fas fa-map-marker-alt" aria-hidden="true"></span> <span>' . $this->params->get('contact_location') . '</span></div>';
			}

			if($this->params->get('contact_phone'))
			{
				$output .= '<div class="sp-contact-phone"><a class="uk-link-reset" href="tel:' . str_replace(array(')','(',' ','-'),array('','','',''), $this->params->get('contact_phone')) . '"><span class="fas fa-phone-alt" aria-hidden="true"></span> <span>' . $this->params->get('contact_phone') . '</span></a></div>';
			}

			if($this->params->get('contact_email'))
			{
				$output .= '<div class="sp-contact-email"><a class="uk-link-reset" href="mailto:'. $this->params->get('contact_email') .'"><span class="far fa-envelope" aria-hidden="true"></span> ' . $this->params->get('contact_email') . '</a></div>';
			}

			if($this->params->get('contact_time'))
			{
				$output .= '<div class="sp-contact-time"><span class="far fa-clock" aria-hidden="true"></span> <span>' . $this->params->get('contact_time') . '</span></div>';
			}

			if($this->params->get('contact_custom'))
			{
				$output .= '<div class="sp-contact-custom">' . $this->params->get('contact_custom') . '</div>';
			}

			$output .= '</div>';

			return $output;
		}

	}
}
