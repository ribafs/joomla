<?php
/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
*/

defined ('_JEXEC') or die();

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');

JHtml::_('behavior.caption');

$app = JFactory::getApplication();

$this->category->text = $this->category->description;
$app->triggerEvent('onContentPrepare', array($this->category->extension . '.categories', &$this->category, &$this->params, 0));
$this->category->description = $this->category->text;

$results = $app->triggerEvent('onContentAfterTitle', array($this->category->extension . '.categories', &$this->category, &$this->params, 0));
$afterDisplayTitle = trim(implode("\n", $results));

$results = $app->triggerEvent('onContentBeforeDisplay', array($this->category->extension . '.categories', &$this->category, &$this->params, 0));
$beforeDisplayContent = trim(implode("\n", $results));

$results = $app->triggerEvent('onContentAfterDisplay', array($this->category->extension . '.categories', &$this->category, &$this->params, 0));
$afterDisplayContent = trim(implode("\n", $results));
$tmpl_params = JFactory::getApplication()->getTemplate(true)->params;

$blog_list_grid_column_gap = $tmpl_params->get('blog_list_grid_column_gap', 'default');
$blog_list_grid_column_gap_cls = $blog_list_grid_column_gap == 'default' ? '' : ' uk-grid-column-'.$blog_list_grid_column_gap;

$blog_list_grid_row_gap = $tmpl_params->get('blog_list_grid_row_gap', 'default');
$blog_list_grid_row_gap_cls = $blog_list_grid_row_gap == 'default' ? '' : ' uk-grid-row-'.$blog_list_grid_row_gap;

$blog_list_breakpoint = $tmpl_params->get('blog_list_breakpoint', 'm');

$blog_masonry = $tmpl_params->get('blog_masonry') ? 'masonry: true;' : '';
$blog_parallax = $tmpl_params->get('blog_parallax', '');
$blog_parallax_cls = $blog_parallax ? ' parallax: '.$blog_parallax : '';


?>

<div class="blog<?php echo $this->pageclass_sfx; ?>" uk-height-viewport="expand: true">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		</div>
	<?php endif; ?>

	<?php if ($this->params->get('show_category_title', 1) or $this->params->get('page_subheading')) : ?>
		<h2>
			<?php echo $this->escape($this->params->get('page_subheading')); ?>
			<?php if ($this->params->get('show_category_title')) : ?>
				<span class="subheading-category"><?php echo $this->category->title; ?></span>
			<?php endif; ?>
		</h2>
	<?php endif; ?>
	<?php echo $afterDisplayTitle; ?>

	<?php if ($this->params->get('show_cat_tags', 1) && !empty($this->category->tags->itemTags)) : ?>
		<?php $this->category->tagLayout = new JLayoutFile('joomla.content.tags'); ?>
		<?php echo $this->category->tagLayout->render($this->category->tags->itemTags); ?>
	<?php endif; ?>

	<?php if ($beforeDisplayContent || $afterDisplayContent || $this->params->get('show_description', 1) || $this->params->def('show_description_image', 1)) : ?>
		<div class="category-desc clearfix">
			<?php if ($this->params->get('show_description_image') && $this->category->getParams()->get('image')) : ?>
				<img src="<?php echo $this->category->getParams()->get('image'); ?>" alt="<?php echo htmlspecialchars($this->category->getParams()->get('image_alt'), ENT_COMPAT, 'UTF-8'); ?>">
			<?php endif; ?>
			<?php echo $beforeDisplayContent; ?>
			<?php if ($this->params->get('show_description') && $this->category->description) : ?>
				<?php echo JHtml::_('content.prepare', $this->category->description, '', 'com_content.category'); ?>
			<?php endif; ?>
			<?php echo $afterDisplayContent; ?>
		</div>
	<?php endif; ?>

	<?php if (empty($this->lead_items) && empty($this->link_items) && empty($this->intro_items)) : ?>
		<?php if ($this->params->get('show_no_articles', 1)) : ?>
			<p><?php echo JText::_('COM_CONTENT_NO_ARTICLES'); ?></p>
		<?php endif; ?>
	<?php endif; ?>

	<?php if (!empty($this->lead_items)) : ?>
			<?php foreach ($this->lead_items as &$item) : ?>

			<?php 

			$url = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catid, $item->language));
			$root = JURI::base();
			$root = new JURI($root);
			$url = $root->getScheme() . '://' . $root->getHost() . $url;

			?>
				<article id="article-<?= $item->id ?>" class="uk-article uk-margin-medium<?php echo $item->state == 0 ? ' system-unpublished' : null; ?>" data-permalink="<?php echo $url; ?>" typeof="Article">
					<meta property="name" content="<?= $item->title ?>">				
    				<meta property="author" typeof="Person" content="<?= $item->author ?>">
					<meta property="dateModified" content="<?= JHtml::_(
						'date', $item->modified,
						$this->escape($this->params->get('date_format', JText::_('c')))
					); ?>">
					<meta property="datePublished" content="<?= JHtml::_(
						'date', $item->displayDate,
						$this->escape($this->params->get('date_format', JText::_('c')))
					); ?>">
					<meta class="uk-margin-remove-adjacent" property="articleSection" content="<?= $item->category_title ?>">
					<?php
					$this->item = & $item;
					$this->item->leading = true;
					echo $this->loadTemplate('item');
					?>
				</article>
			<?php endforeach; ?>
	<?php endif; ?>

	<?php
	$introcount = count($this->intro_items);
	$counter = 0;
	?>

<?php if ($this->columns != 1) : ?>
<div class="article-list uk-child-width-1-<?php echo $this->columns; ?>@<?php echo $blog_list_breakpoint; echo $blog_list_grid_column_gap_cls; echo $blog_list_grid_row_gap_cls; ?>" uk-grid="<?php echo $blog_masonry; echo $blog_parallax_cls; ?>" uk-height-viewport="expand: true">
	<?php endif ?>
	
	<?php if (!empty($this->intro_items)) : ?>
		
			<?php foreach ($this->intro_items as $key => &$item) : ?>
			<?php 

			$url = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catid, $item->language));
			$root = JURI::base();
			$root = new JURI($root);
			$url = $root->getScheme() . '://' . $root->getHost() . $url;

			?>				

				<?php if ($this->columns != 1) : ?>
				<div>
				<?php endif ?>

					<article id="article-<?= $item->id ?>" class="uk-article<?php echo $item->state == 0 ? ' system-unpublished' : null; ?>" data-permalink="<?php echo $url; ?>" typeof="Article">
					<meta property="name" content="<?= $item->title ?>">				
    				<meta property="author" typeof="Person" content="<?= $item->author ?>">
					<meta property="dateModified" content="<?= JHtml::_(
						'date', $item->modified,
						$this->escape($this->params->get('date_format', JText::_('c')))
					); ?>">
					<meta property="datePublished" content="<?= JHtml::_(
						'date', $item->displayDate,
						$this->escape($this->params->get('date_format', JText::_('c')))
					); ?>">
					<meta class="uk-margin-remove-adjacent" property="articleSection" content="<?= $item->category_title ?>">					
						<?php
						$this->item = & $item;
						echo $this->loadTemplate('item');
						?>
					</article>
					<?php $counter++; ?>

					<?php if ($this->columns != 1) : ?>
    </div>
    <?php endif ?>
			<?php endforeach; ?>
	<?php endif; ?>

    <?php if ($this->columns != 1) : ?>
    </div>
    <?php endif ?>

	<?php if (!empty($this->link_items)) : ?>
		<div class="articles-more uk-margin-large">
			<h3><?php echo JText::_('HELIX_ULTIMATE_MORE_ARTICLES'); ?></h3>
			<?php echo $this->loadTemplate('links'); ?>
		</div>
	<?php endif; ?>

	<?php if ($this->maxLevel != 0 && !empty($this->children[$this->category->id])) : ?>
		<div class="cat-children">
			<?php if ($this->params->get('show_category_heading_title_text', 1) == 1) : ?>
				<h3> <?php echo JText::_('JGLOBAL_SUBCATEGORIES'); ?> </h3>
			<?php endif; ?>
			<?php echo $this->loadTemplate('children'); ?> </div>
	<?php endif; ?>

	<?php if (($this->params->def('show_pagination', 1) == 1 || ($this->params->get('show_pagination') == 2)) && ($this->pagination->pagesTotal > 1)) : ?>
		
			<?php if ($this->params->def('show_pagination_results', 1)) : ?>
			<?php echo $this->pagination->getPagesLinks(); ?>
			<?php endif; ?>
			
	<?php endif; ?>

</div>
