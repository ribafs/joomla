<?php
/*
# mod_sp_quickcontact - Ajax based quick contact Module by JoomShaper.com
# -----------------------------------------------------------------------
# Author    JoomShaper http://www.joomshaper.com
# Copyright (C) 2010 - 2014 JoomShaper.com. All Rights Reserved.
# License - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.joomshaper.com
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div id="sp_quickcontact<?php echo $uniqid ?>" class="sp_quickcontact">
	<div id="sp_qc_status"></div>
	<form id="sp-quickcontact-form" class="uk-form">
		<div class="sp_qc_clr"></div>
		<input class="uk-input uk-form-large" type="text" name="name" id="name" onfocus="if (this.value=='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_NAME'); ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_NAME'); ?>';" value="<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_NAME'); ?>" required />
		<div class="sp_qc_clr"></div>
		<input class="uk-input uk-form-large"type="email" name="email" id="email" onfocus="if (this.value=='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_EMAIL'); ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_EMAIL'); ?>';" value="<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_EMAIL'); ?>" required />
		<div class="sp_qc_clr"></div>
		<input class="uk-input uk-form-large"type="text" name="subject" id="subject" onfocus="if (this.value=='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_SUBJECT'); ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_SUBJECT'); ?>';" value="<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_SUBJECT'); ?>" />
		<div class="sp_qc_clr"></div>
		<textarea class="uk-textarea uk-form-large" name="message" id="message" onfocus="if (this.value=='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_MESSAGE'); ?>') this.value='';" onblur="if (this.value=='') this.value='<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_MESSAGE'); ?>';" cols="" rows=""><?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_MESSAGE'); ?></textarea>
		<div class="sp_qc_clr"></div>
		<?php if($formcaptcha) { ?>
			<input class="uk-input uk-form-width-small uk-form-large" type="text" name="sccaptcha" placeholder="<?php echo $captcha_question ?>" required />
		<?php } ?>
		<div class="sp_qc_clr"></div>
		<input id="sp_qc_submit" class="uk-button uk-button-primary uk-button-large uk-width-1-1" type="submit" value="<?php echo JText::_('HELIX_ULTIMATE_SP_QUICK_CT_SEND_MESSAGE'); ?>" />
		<div class="sp_qc_clr"></div>
	</form>
</div>
