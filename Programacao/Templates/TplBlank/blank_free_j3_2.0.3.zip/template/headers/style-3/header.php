<?php

/**
 * Blank Free Stacked Header
 */

defined('_JEXEC') or die();
$doc = \JFactory::getDocument();
$data = $displayData;
$attrs_sticky[] = '';
$mobile_sticky_init[] = '';
$offcanvs_position = $data->params->get('offcanvas_position', 'right');
$navbar_search = $data->params->get('search_position');
$feature_folder_path     = JPATH_THEMES . '/' . $data->template->template . '/features/';
$mobile_breakpoint_options = $data->params->get('mobile_breakpoint_options', 'm');
$mobile_sticky = $data->params->get('mobile_navbar_options', '0');
$mobile_logo = $data->params->get('mobile_logo_options', 'center');
$mobile_toggle = $data->params->get('mobile_toggle_options', 'left');
$mobile_toggle_text = $data->params->get('mobile_toggle_text', '0');
$mobile_animations = $data->params->get('mobile_animations', 'offcanvas');
$mobile_offcanvas_mode = $data->params->get('mobile_offcanvas_mode', 'slide');
$mobile_dropdown_toggle = $mobile_animations == 'dropdown' ? '="animation: true"' : '';
$mobile_dropdown_animation_cls = $mobile_offcanvas_mode == 'slide' ? ' class="uk-position-top"' : '';

$mobile_menu_center_vertical = $data->params->get('mobile_menu_center_vertical', '0');
$mobile_center_text = $data->params->get('mobile_center_horizontally', '0');
$mobile_center_text_cls = $mobile_center_text ? ' uk-text-center uk-nav-center' : '';

$flex_cls = $mobile_menu_center_vertical ? ' uk-flex' : '';

$mobile_menu_offcanvas_right = $data->params->get('mobile_menu_offcanvas_right', '0');

$offcanvas_flip = $mobile_menu_offcanvas_right ? ' flip: true;' : '';

if ( $mobile_sticky ) {
  $mobile_sticky_init[] = 'cls-active: uk-navbar-sticky';
	$mobile_sticky_init[] = 'sel-target: .uk-navbar-container';  
	if ( '2' === $mobile_sticky ) {
    $mobile_sticky_init[] = 'show-on-up: true';
    $mobile_sticky_init[] = 'animation: uk-animation-slide-top';
	}
}

include_once $feature_folder_path . 'logo.php';
include_once $feature_folder_path . 'social.php';
include_once $feature_folder_path . 'contact.php';
include_once $feature_folder_path . 'menu.php';
include_once $feature_folder_path . 'search.php';
include_once $feature_folder_path . 'cookie.php';

$headerbar_top = '';
$header_wrap[] = '';
$header_wrap[] = 'tm-header uk-visible@' . $mobile_breakpoint_options;

$header_outside = $data->params->get('boxed_layout') && $data->params->get('boxed_header_outside');
$transparent_header = $data->params->get('transparent_header');

$headerbar_top = $header_outside && $transparent_header ? ' uk-' . $transparent_header  : '';

// Toolbar.
$toolbar_wrap[] = 'tm-toolbar';
$toolbar_transparent = $data->params->get('toolbar_transparent') && $transparent_header;
$toolbar_wrap[] = $header_outside && $toolbar_transparent ? 'uk-' . $transparent_header : 'tm-toolbar-default';
$toolbar_wrap[] = ! $header_outside && $toolbar_transparent ? 'tm-toolbar-transparent' : '';
$toolbar_wrap[] = 'uk-visible@'.$mobile_breakpoint_options;

$toolbar_container = $data->params->get('toolbar_maxwidth', 'default');
$toolbar_container_cls[] = 'uk-flex uk-flex-middle';

// Navbar Container
$navbar_container[] = 'uk-navbar-container';
$header_menu_style = $data->params->get('header_menu_options') ? ' uk-navbar-primary' : '';
$sticky = $data->params->get('header_navbar');

if ( $sticky ) {

	$attrs_sticky[] = 'sel-target: .uk-navbar-container';
	$attrs_sticky[] = 'cls-active: uk-navbar-sticky';
	$attrs_sticky[] = 'media: @' . $mobile_breakpoint_options;

	if ( '2' === $sticky ) {
		$attrs_sticky[] = 'animation: uk-animation-slide-top';
		$attrs_sticky[] = 'show-on-up: true';
	}
}

if ( $header_outside && $transparent_header ) {

	$header_wrap[] = 'tm-header-transparent';

	if ( $sticky ) {
		$attrs_sticky[] = 'cls-inactive: uk-navbar-transparent uk-' . $transparent_header;
		$attrs_sticky[] = 'top: 300';
		if ( '1' === $sticky ) {
			$attrs_sticky[] = 'animation: uk-animation-slide-top';
		}
	} else {
		$navbar_container[] = 'uk-navbar-transparent uk-' . $transparent_header;
	}
}

$transparent_header_cls = ($transparent_header && $header_outside) ? ' uk-navbar-transparent uk-' . $transparent_header : '';

$toolbar_center = $data->params->get('toolbar_center', '0');
$header_container = $data->params->get('header_maxwidth', 'default');

// Width Container
$header_container_cls[] = '';

if ($header_outside) {
    $header_container_cls[] = $header_container == 'expand' ? 'uk-container uk-container-expand' : 'container tm-page-width';
    $toolbar_container_cls[] = $toolbar_container == 'expand' ? 'uk-container uk-container-expand' : 'container tm-page-width';
} else {
    $header_container_cls[] = $header_container != 'default' ? 'uk-container uk-container-' . $header_container : 'container';
    $toolbar_container_cls[] = $toolbar_container != 'default' ? 'uk-container uk-container-' . $toolbar_container : 'container';
}

$toolbar_container_cls[] = $data->params->get('toolbar_center') ? 'uk-flex-center' : '';

$toolbar_wrap   = implode( ' ', array_filter( $toolbar_wrap ) );
$toolbar_container_cls   = implode( ' ', array_filter( $toolbar_container_cls ) );
$header_wrap   = implode( ' ', array_filter( $header_wrap ) );
$attrs_sticky = ' uk-sticky="' . implode( '; ', array_filter( $attrs_sticky ) ) . '"';
$mobile_sticky_init = ' uk-sticky="' . implode( '; ', array_filter( $mobile_sticky_init ) ) . '"';
$header_container_cls   = implode( ' ', array_filter( $header_container_cls ) );
$navbar_container   = implode( ' ', array_filter( $navbar_container ) );

$output  = '';
$cookie    = new HelixUltimateFeatureCookie($data->params);
$output .= $cookie->renderFeature();

$output  .= '<div class="tm-header-mobile uk-hidden@' . $mobile_breakpoint_options . '">';

if ( $mobile_sticky ) {
  $output  .= '<div' . $mobile_sticky_init . '>';
}

$output  .= '<div class="uk-navbar-container">';
$output  .= '<nav class="uk-navbar" uk-navbar>';

if ($mobile_logo == 'left' || $mobile_toggle == 'left') {
  $output  .= '<div class="uk-navbar-left">';

  if ($mobile_logo == 'left') {

    $logo    = new HelixUltimateFeatureLogo($data->params);
    if (isset($logo->load_pos) && $logo->load_pos == 'before') {
      $output .= $logo->renderFeature();
      $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
    } else {
      $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
      $output .= $logo->renderFeature();
    }
  }

  if ($mobile_toggle == 'left') {
    $output .= '<a class="uk-navbar-toggle" href="#tm-mobile" uk-toggle' . $mobile_dropdown_toggle . '>';
    $output .= '<div uk-navbar-toggle-icon></div>';
    if ($mobile_toggle_text) {
      $output .= '<span class="uk-margin-small-left">' . JText::_('TPL_HELIX_ULTIMATE_MENU') . '</span>';
    }

    $output .= '</a>';
  }

  $output  .= '</div>';
}

if ($mobile_logo == 'center') {
  $output  .= '<div class="uk-navbar-center">';
  $logo    = new HelixUltimateFeatureLogo($data->params);
  if (isset($logo->load_pos) && $logo->load_pos == 'before') {
    $output .= $logo->renderFeature();
    $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
  } else {
    $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
    $output .= $logo->renderFeature();
  }
  $output  .= '</div>';
}

if ($mobile_logo == 'right' || $mobile_toggle == 'right') {
  $output  .= '<div class="uk-navbar-right">';

  if ($mobile_toggle == 'right') {
    $output .= '<a class="uk-navbar-toggle" href="#tm-mobile" uk-toggle' . $mobile_dropdown_toggle . '>';
    $output .= '<div uk-navbar-toggle-icon></div>';
    if ($mobile_toggle_text) {
      $output .= '<span class="uk-margin-small-left">' . JText::_('TPL_HELIX_ULTIMATE_MENU') . '</span>';
    }
    $output .= '</a>';
  }

  if ($mobile_logo == 'right') {
    $logo    = new HelixUltimateFeatureLogo($data->params);
    if (isset($logo->load_pos) && $logo->load_pos == 'before') {
      $output .= $logo->renderFeature();
      $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
    } else {
      $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
      $output .= $logo->renderFeature();
    }
  }

  $output  .= '</div>';
}

$output  .= '</nav>';
$output  .= '</div>';

if ($mobile_animations == 'dropdown') {

  if ($mobile_offcanvas_mode == 'slide') {
    $output  .= '<div class="uk-position-relative tm-header-mobile-slide">';
  }

  $output  .= '<div id="tm-mobile"' . $mobile_dropdown_animation_cls . ' hidden>';
  $output  .= '<div class="uk-background-default uk-padding'.$mobile_center_text_cls.'">';

  $output  .= '<div class="uk-child-width-1-1" uk-grid>';
  $output  .= '<jdoc:include type="modules" name="offcanvas" style="grid_stack" />';
  $output  .= '</div>';

  $output  .= '</div>';
  $output  .= '</div>';

  if ($mobile_offcanvas_mode == 'slide') {
    $output  .= '</div>';
  }
}

if ( $mobile_sticky ) {
  $output  .= '</div>';
}

if ($mobile_animations == 'offcanvas') {
  $output  .= '<div id="tm-mobile" class="uk-offcanvas" uk-offcanvas="mode:' . $mobile_offcanvas_mode . ';' . $offcanvas_flip . ' overlay: true">';
  $output  .= '<div class="uk-offcanvas-bar'.$mobile_center_text_cls.$flex_cls.'">';

  $output  .= '<button class="uk-offcanvas-close" type="button" uk-close></button>';

  if ($mobile_menu_center_vertical) {
    $output  .= '<div class="uk-margin-auto-vertical uk-width-1-1">';
  }

  $output  .= '<div class="uk-child-width-1-1" uk-grid>';
  $output  .= '<jdoc:include type="modules" name="offcanvas" style="grid_stack" />';
  $output  .= '</div>';
  if ($mobile_menu_center_vertical) {
    $output  .= '</div>';
  }

  $output  .= '</div>';
  $output  .= '</div>';
}

if ($mobile_animations == 'modal') {
  $output  .= '<div id="tm-mobile" class="uk-modal-full" uk-modal>';
  $output  .= '<div class="uk-modal-dialog uk-modal-body' . $mobile_center_text_cls . $flex_cls . ' uk-height-viewport">';

  $output  .= '<button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>';

  if ($mobile_menu_center_vertical) {
    $output  .= '<div class="uk-margin-auto-vertical uk-width-1-1">';
  }

  $output  .= '<div class="uk-child-width-1-1" uk-grid>';
  $output  .= '<jdoc:include type="modules" name="offcanvas" style="grid_stack" />';
  $output  .= '</div>';

  if ($mobile_menu_center_vertical) {
    $output  .= '</div>';
  }

  $output  .= '</div>';
  $output  .= '</div>';
}

$output  .= '</div>';

$social = new HelixUltimateFeatureSocial($data->params);
$social_pos = $data->params->get('social_pos');

$contact = new HelixUltimateFeatureContact($data->params);
$contact_pos = $data->params->get('contact_pos');

if ( ! $toolbar_transparent ) {

  if ($doc->countModules('toolbar-left') || $doc->countModules('toolbar-right') || $social_pos == 'toolbar-left' || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-left' || $contact_pos == 'toolbar-right') {
    $output .= '<div class="' . $toolbar_wrap . '">';
    $output .= '<div class="' . $toolbar_container_cls . '">';
  
    if ($toolbar_center) {
  
      $output .= '<div>';
      $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
      if ($doc->countModules('toolbar-left') || $social_pos == 'toolbar-left' || $contact_pos == 'toolbar-left') {
  
        if ($contact_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '<jdoc:include type="modules" name="toolbar-left" style="toolbar_stack" />';
      }
  
      if ($doc->countModules('toolbar-right') || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-right') {
  
        $output .= '<jdoc:include type="modules" name="toolbar-right" style="toolbar_stack" />';
  
        if ($contact_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
      }
      $output .= '</div>';
      $output .= '</div>';
    } else {
  
      if ($doc->countModules('toolbar-left') || $social_pos == 'toolbar-left' || $contact_pos == 'toolbar-left') {
  
        $output .= '<div class="toolbar-left">';
        $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
        if ($contact_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '<jdoc:include type="modules" name="toolbar-left" style="toolbar_stack" />';
  
        $output .= '</div>';
        $output .= '</div>';
      }
  
      if ($doc->countModules('toolbar-right') || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-right') {
  
        $output .= '<div class="toolbar-right uk-margin-auto-left">';
        $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
  
        $output .= '<jdoc:include type="modules" name="toolbar-right" style="toolbar_stack" />';
  
        if ($contact_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '</div>';
        $output .= '</div>';
      }
    }
  
    $output .= '</div>';
    $output .= '</div>';
  }
  
  }

$output .= '<div class="' . $header_wrap . '" uk-header>';
if ( $toolbar_transparent ) {

  if ($doc->countModules('toolbar-left') || $doc->countModules('toolbar-right') || $social_pos == 'toolbar-left' || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-left' || $contact_pos == 'toolbar-right') {
    $output .= '<div class="' . $toolbar_wrap . '">';
    $output .= '<div class="' . $toolbar_container_cls . '">';
  
    if ($toolbar_center) {
  
      $output .= '<div>';
      $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
      if ($doc->countModules('toolbar-left') || $social_pos == 'toolbar-left' || $contact_pos == 'toolbar-left') {
  
        if ($contact_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '<jdoc:include type="modules" name="toolbar-left" style="toolbar_stack" />';
      }
  
      if ($doc->countModules('toolbar-right') || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-right') {
  
        $output .= '<jdoc:include type="modules" name="toolbar-right" style="toolbar_stack" />';
  
        if ($contact_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
      }
      $output .= '</div>';
      $output .= '</div>';
    } else {
  
      if ($doc->countModules('toolbar-left') || $social_pos == 'toolbar-left' || $contact_pos == 'toolbar-left') {
  
        $output .= '<div class="toolbar-left">';
        $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
        if ($contact_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-left') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '<jdoc:include type="modules" name="toolbar-left" style="toolbar_stack" />';
  
        $output .= '</div>';
        $output .= '</div>';
      }
  
      if ($doc->countModules('toolbar-right') || $social_pos == 'toolbar-right' || $contact_pos == 'toolbar-right') {
  
        $output .= '<div class="toolbar-right uk-margin-auto-left">';
        $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-middle" uk-grid="margin: uk-margin-small-top">';
  
  
        $output .= '<jdoc:include type="modules" name="toolbar-right" style="toolbar_stack" />';
  
        if ($contact_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $contact->renderFeature();
          $output .= '</div>';
        }
  
        if ($social_pos == 'toolbar-right') {
          $output .= '<div>';
          $output .= $social->renderFeature();
          $output .= '</div>';
        }
  
        $output .= '</div>';
        $output .= '</div>';
      }
    }
  
    $output .= '</div>';
    $output .= '</div>';
  }
  
  }
$output .= '<div class="tm-headerbar-top'.$headerbar_top.'">';
$output .= '<div class="' . $header_container_cls . ' uk-flex uk-flex-middle">';

$logo    = new HelixUltimateFeatureLogo($data->params);
if (isset($logo->load_pos) && $logo->load_pos == 'before') {
  $output .= $logo->renderFeature();
  $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
} else {
  $output .= '<jdoc:include type="modules" name="logo" style="sp_xhtml" />';
  $output .= $logo->renderFeature();
}

if ($doc->countModules('header') || $navbar_search == 'header' || $social_pos == 'header') {

  $output .= '<div class="uk-margin-auto-left">';

  $output .= '<div class="uk-grid-medium uk-child-width-auto uk-flex-center uk-flex-middle" uk-grid>';
  if ($doc->countModules('header')) {
    $output .= '<jdoc:include type="modules" name="header" style="header_xhtml" />';
  }

  if ($navbar_search == 'header') {
    $search    = new HelixUltimateFeatureSearch($data->params);
    $output .= '<div>';
    $output .= $search->renderFeature();
    $output .= '</div>';
  }

  if ($social_pos == 'header') {
    $output .= '<div>';
    $output .= $social->renderFeature();
    $output .= '</div>';
  }
  $output .= '</div>';

  $output .= '</div>';
}

$output .= '</div>';
$output .= '</div>';

if ($sticky) {
  $output .= '<div' . $attrs_sticky . '>';
}

$output .= '<div class="'.$navbar_container.$header_menu_style.'">';

$output .= '<div class="' . $header_container_cls . '">';
$output .= '<nav class="uk-navbar" uk-navbar>';

$output .= '<div class="uk-navbar-left">';

$menu    = new HelixUltimateFeatureMenu($data->params);
if (isset($menu->load_pos) && $menu->load_pos == 'before') {
  $output .= $menu->renderFeature();
  $output .= '<jdoc:include type="modules" name="menu" style="sp_xhtml" />';
} else {
  $output .= '<jdoc:include type="modules" name="menu" style="sp_xhtml" />';
  $output .= $menu->renderFeature();
}

$output .= '</div>';

$output .= '<div class="uk-navbar-right">';

if ($doc->countModules('navbar')) {
  $output .= '<jdoc:include type="modules" name="navbar" style="warp_xhtml" />';
}

if ($navbar_search == 'navbar') {
  $search    = new HelixUltimateFeatureSearch($data->params);
  $output .= '<div class="uk-navbar-item">';
  $output .= $search->renderFeature();
  $output .= '</div>';
}

if ($social_pos == 'navbar') {
  $output .= '<div class="uk-navbar-item">';
  $output .= $social->renderFeature();
  $output .= '</div>';
}

$output .= '</div>';

$output .= '</nav>';
$output .= '</div>';

$output .= '</div>';

if ($sticky) {
  $output .= '</div>';
}

$output .= '</div>';

echo $output;
