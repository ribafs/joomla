<?php

/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
 */

defined('_JEXEC') or die();

$doc = JFactory::getDocument();
$app = JFactory::getApplication();

$helix_path = JPATH_PLUGINS . '/system/helixultimate/core/helixultimate.php';
if (file_exists($helix_path)) {
    require_once($helix_path);
    $theme = new helixUltimate;
} else {
    die('Install and activate <a target="_blank" href="https://www.joomshaper.com/helix">Helix Ultimate Framework</a>.');
}

// If comingsoon is enabled and logged in user doens't have permission to login in the offline then redirect to comingsoon page
if ( $this->params->get('comingsoon') && !\JFactory::getUser()->authorise('core.login.offline') )
{
  header("Location: " . $this->baseUrl . "?tmpl=comingsoon");
}

$custom_style = $this->params->get('custom_style');
$preset = $this->params->get('preset');
$offcanvs_position = $this->params->get('offcanvas_position', 'right');
if ($custom_style || !$preset) {
    $scssVars = array(
        'preset' => 'default',
        'text_color' => $this->params->get('text_color'),
        'bg_color' => $this->params->get('bg_color'),
        'link_color' => $this->params->get('link_color'),
        'link_hover_color' => $this->params->get('link_hover_color'),
        'second_link_color' => $this->params->get('second_link_color'),
        'header_top_bg_color' => $this->params->get('header_top_bg_color'), 
        'header_bg_color' => $this->params->get('header_bg_color'), 
        'header_bottom_bg_color' => $this->params->get('header_bottom_bg_color'), 
        'logo_text_color' => $this->params->get('logo_text_color'),
        'header_bg_mobile_color' => $this->params->get('header_bg_mobile_color'), 
        'logo_text_mobile_color' => $this->params->get('logo_text_mobile_color'),
        'toggle_mobile_color' => $this->params->get('toggle_mobile_color'),
        'menu_text_color' => $this->params->get('menu_text_color'),
        'menu_text_hover_color' => $this->params->get('menu_text_hover_color'),
        'menu_text_active_color' => $this->params->get('menu_text_active_color'),
        'menu_dropdown_bg_color' => $this->params->get('menu_dropdown_bg_color'),
        'menu_dropdown_text_color' => $this->params->get('menu_dropdown_text_color'),
        'menu_dropdown_text_hover_color' => $this->params->get('menu_dropdown_text_hover_color'),
        'menu_dropdown_text_active_color' => $this->params->get('menu_dropdown_text_active_color'),
        'bottom_bg_color' => $this->params->get('bottom_bg_color'),
        'bottom_title_color' => $this->params->get('bottom_title_color'),
        'bottom_text_color' => $this->params->get('bottom_text_color'),
        'bottom_link_color' => $this->params->get('bottom_link_color'),
        'bottom_link_hover_color' => $this->params->get('bottom_link_hover_color'),        
        'footer_bg_color' => $this->params->get('footer_bg_color'),
        'footer_text_color' => $this->params->get('footer_text_color'),
        'footer_link_color' => $this->params->get('footer_link_color'),
        'footer_link_hover_color' => $this->params->get('footer_link_hover_color'),
        'topbar_bg_color' => $this->params->get('topbar_bg_color'),
        'topbar_text_color' => $this->params->get('topbar_text_color')
    );
} else {
    $scssVars = (array) json_decode($this->params->get('preset'));
}
$scssVars['header_stacked_margin'] = $this->params->get('header_stacked_margin', '20px');
$scssVars['topbar_padding_top'] = $this->params->get('topbar_padding_top', '10px');
$scssVars['topbar_padding_bottom'] = $this->params->get('topbar_padding_bottom', '10px');
$scssVars['header_height'] = $this->params->get('header_height', '82px');
$scssVars['header_top_padding_top'] = $this->params->get('header_top_padding_top', '20px 0');
$scssVars['header_bottom_padding_top'] = $this->params->get('header_bottom_padding_top', '20px 0');

$scssVars['offcanvas_width'] = $this->params->get('offcanvas_width', '300') . 'px';


//Body Background Image
if ($bg_image = $this->params->get('body_bg_image')) {
    $body_style = 'background-image: url(' . JURI::base(true) . '/' . $bg_image . ');';
    $body_style .= 'background-repeat: ' . $this->params->get('body_bg_repeat') . ';';
    $body_style .= 'background-size: ' . $this->params->get('body_bg_size') . ';';
    $body_style .= 'background-attachment: ' . $this->params->get('body_bg_attachment') . ';';
    $body_style .= 'background-position: ' . $this->params->get('body_bg_position') . ';';
    $body_style = 'body.site {' . $body_style . '}';
    $doc->addStyledeclaration($body_style);
}

//Body Background Color
if ($bg_color = $this->params->get('body_bg_color') && $this->params->get('boxed_layout')) {
    $body_style = 'background-color:' . $this->params->get('body_bg_color') . ';';
    $body_style = '@media (min-width: 1240px) {body.site {' . $body_style . '} }';
    $doc->addStyledeclaration($body_style);
}

//Headerbar Top Background Color
if ($header_top_bg_color = $this->params->get('header_top_bg_color') && $custom_style) {
    $body_style = 'background-color:' . $this->params->get('header_top_bg_color') . ';';
    $body_style = '.tm-headerbar-top {' . $body_style . '}';
    $doc->addStyledeclaration($body_style);
}

//Headerbar Bottom Background Color
if ($header_bottom_bg_color = $this->params->get('header_bottom_bg_color') && $custom_style) {
    $body_style = 'background-color:' . $this->params->get('header_bottom_bg_color') . ';';
    $body_style = '.tm-headerbar-bottom {' . $body_style . '}';
    $doc->addStyledeclaration($body_style);
}

//Header Height
if ($header_height = $this->params->get('header_height')) {
    $body_style = 'line-height:' . $this->params->get('header_height') . ';';
    $body_style = '.sp-megamenu-parent > li > a, .sp-megamenu-parent > li > span {' . $body_style . '}';
    $doc->addStyledeclaration($body_style);
}

//Header Bar Top Padding 
if ($header_top_padding_top = $this->params->get('header_top_padding_top') ) {
    $headerbar_top = 'padding:' . $this->params->get('header_top_padding_top') . ';';
    $headerbar_top = '.tm-headerbar-top {' . $headerbar_top . '}';
    $doc->addStyledeclaration($headerbar_top);
}

//Header Bar Bottom Padding 
if ($header_bottom_padding_top = $this->params->get('header_bottom_padding_top') ) {
    $headerbar_bottom = 'padding:' . $this->params->get('header_bottom_padding_top') . ';';
    $headerbar_bottom = '.tm-headerbar-bottom {' . $headerbar_bottom . '}';
    $doc->addStyledeclaration($headerbar_bottom);
}

//Header Bar Stacked
if ($header_stacked_margin = $this->params->get('header_stacked_margin')) {
    $header_stacked = 'margin-top:' . $this->params->get('header_stacked_margin') . ';';
    $header_stacked = '.tm-headerbar-stacked {' . $header_stacked . '}';
    $doc->addStyledeclaration($header_stacked);
}

//Custom CSS
if ($custom_css = $this->params->get('custom_css')) {
    $doc->addStyledeclaration($custom_css);
}

// Reading progress bar position
$progress_bar_position = $this->params->get('reading_timeline_position');
if( $app->input->get('view') == 'article' && $this->params->get('reading_time_progress', 0) ) {    
    $progress_style = 'position:fixed;';
    $progress_style .= 'z-index:9999;';
    $progress_style .= 'height:'.$this->params->get('reading_timeline_height').';';
    $progress_style .= 'background-color:'.$this->params->get('reading_timeline_bg').';';
    $progress_style .= $progress_bar_position == 'top' ? 'top:0;' : 'bottom:0;';
    $progress_style = '.sp-reading-progress-bar { '.$progress_style.' }';
    $doc->addStyledeclaration($progress_style);
}

//Custom JS
if ($custom_js = $this->params->get('custom_js')) {
    $doc->addScriptdeclaration($custom_js);
}

$boxed_center = $this->params->get('boxed_center') ? ' uk-margin-auto' : '';
$boxed_top_margin = $this->params->get('boxed_top_margin') ? ' tm-page-margin-top' : '';
$boxed_bottom_margin = $this->params->get('boxed_bottom_margin') ? ' tm-page-margin-bottom' : '';
$boxed_header_outside = $this->params->get('boxed_header_outside');
$tpl_assets = $this->params->get('tpl_assets');
?>

<!doctype html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="canonical" href="<?php echo JUri::getInstance()->toString(); ?>">
    <?php

    $theme->head();
    // CSS files
    $theme->add_css('font-awesome.min.css, fa-v4-shims.css');
    $theme->add_css('custom');
    
    if($this->direction == 'rtl')
    {
        $theme->add_css('uikit-rtl.min.css');
        $theme->add_scss('rtl', $scssVars, 'rtl');
    } else {
        $theme->add_css('uikit.min.css');
    }
    // Scss files
    $theme->add_scss('master', $scssVars, 'template');    
    $theme->add_scss('presets', $scssVars, 'presets/' . $scssVars['preset']);

    // JS files
    $theme->add_js('uikit.min.js,main.js');

    //Icon Library
    if ($tpl_assets) {
        $theme->add_js('uikit-icons.min.js');
    }

    //Before Head
    if ($before_head = $this->params->get('before_head'))
    {
        echo $before_head . "\n";
    }

    ?>
</head>

<body class="<?php echo $theme->bodyClass(); ?>">  

    <?php if ($this->params->get('preloader')) : ?>
        <div id="preloader" class="uk-width-1-1 uk-height-1-1 uk-position-fixed uk-overflow-hidden uk-background-default" style="z-index: 9999;">
            <div class="uk-position-center">
                <span class="uk-text-primary" uk-spinner="ratio: 2"></span>
            </div>
        </div>
    <?php endif; ?>

    <div class="body-wrapper">

        <?php if ($boxed_header_outside) : ?>
            <?php echo $theme->getHeaderStyle(); ?>
        <?php endif; ?>

        <?php if ($this->params->get('boxed_layout')) : ?>
            <div class="tm-page<?php echo $boxed_center;
                                    echo $boxed_top_margin;
                                    echo $boxed_bottom_margin; ?>">
            <?php endif; ?>

            <?php if (!$boxed_header_outside) : ?>
                <?php echo $theme->getHeaderStyle(); ?>
            <?php endif; ?>
            <?php $theme->render_layout(); ?>


            <?php if ($this->params->get('boxed_layout')) : ?>
            </div>
        <?php endif; ?>

    </div>

    <?php $theme->after_body(); ?>

    <jdoc:include type="modules" name="debug" style="none" />

    <?php if ($this->params->get('preloader')) : ?>
        <script>
            jQuery(function($) {
                $(window).on('load', function() {
                    $('#preloader').fadeOut(500, function() {
                        $(this).remove();
                    });
                });
            });
        </script>
    <?php endif; ?>

    <!-- Go to top -->
    <?php if ($this->params->get('goto_top', 0)) : ?>
    <a href="#" class="back__top" aria-label="Scroll Up"><span class="fa fa-chevron-up" aria-hidden="true"></span></a>
    <?php endif; ?>
    <?php if ($app->input->get('view') == 'article' && $this->params->get('reading_time_progress', 0)) : ?>
        <div data-position="<?php echo $progress_bar_position; ?>" class="sp-reading-progress-bar"></div>
    <?php endif; ?>
</body>

</html>