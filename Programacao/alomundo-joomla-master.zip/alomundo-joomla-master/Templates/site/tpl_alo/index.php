<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<jdoc:include type="head" />
</head>

<body>
	<div>
		<h1>Alô mundo do Joomla - Template</h1>
	</div>
</body>
</html>

