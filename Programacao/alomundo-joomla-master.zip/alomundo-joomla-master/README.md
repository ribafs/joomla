# alomundo-joomla - Extensões do tipo hello world para Joomla 3

## Aqui trago as extensões:

- componente para o admin
- componente para o site
- módulo para o site
- plugin do tipo content para o site
- template para o site

Todos do tipo hello world, ou seja, apenas mostrando uma pequena frase.

Deles é útil apenas o xml, que pode ser aproveitado para outras extensões criadas.

A ideia não é ensinar a criar componentes mas apenas dar o pontapé inicial.

Para aprender a criar componentes veja o e-book Programação para Joomla em
http://ribafs.org/portal/curriculo/livros.html

## Licença
GPL 3

