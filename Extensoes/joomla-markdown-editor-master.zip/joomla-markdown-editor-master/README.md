## Joomla! Markdown Editor - JME
Better Markdown Editor for Joomla! based on Parsedown and Codemirror

### Features
* Super Fast
* [Parsedown](https://github.com/erusev/parsedown)
* [GitHub flavored](https://help.github.com/articles/github-flavored-markdown)
* [Markdown Extra extension](https://github.com/erusev/parsedown-extra)

### Installation
Download from Latest Release and install it from joomla administration installation.

**Credits**
The entire concept is taken from [Grav](https://github.com/getgrav/grav). The main editor script also mostly same as grav framework, modified only necessary pert.