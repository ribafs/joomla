<h2>Version: 1.0.0 (22/05/2016)</h2>
<h3>Initial Release</h3>
- First version with very basic update of editor.