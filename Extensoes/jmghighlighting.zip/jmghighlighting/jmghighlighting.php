<?php
/**
 * System Plugin for Joomla! - JMG Highlighting
 * @package     Joomla.Site
 * @subpackage  jmghighlighting
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * Class PlgSystemJmgHighlighting
 *
 * @since  1.0.0
 */
class PlgSystemJmghighlighting extends JPlugin
{
	protected $autoloadLanguage = true;
	protected $app;
	
	public function onAfterRender(){
		// Don't run this plugin in the Admin
		if ($this->app->isSite() == false){
			return;
		}
		
		$body = $this->app->getBody();		
		$body = $this->replace($body);
		$this->app->setBody($body);
	}
	
	public function replace($text){
		
		$jmgkeywords = $this->params->get('jmgkeywords');
		
		foreach($jmgkeywords as $keyword){
			$text = preg_replace('/'.$keyword->keyword.'/', '<span style="background:'.$keyword->backgroundcolor.';">'.$keyword->keyword.'</span>', $text);
		}
		
		return $text;
	}
}
